[size=x-large][b]Hide Message Icons[/b][/size]

A modification for SMF 2.1 that hides the message icon feature.
[list]
[li]The "Message Icon" select menu is removed from the post editor's header[/li]
[li]The message icon is always hidden in the topic display[/li]
[li]The message icon is hidden on the message index (except for the poll, moved, and recycled icons)[/li]
[/list]

There are no settings. Install to enable the mod, uninstall to disable it.

[size=large][b]License[/b][/size]

Hide Message Icons is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]