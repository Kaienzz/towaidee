<?php
/********************************************************************************************
* db_install.php																  			*												
*********************************************************************************************
*																				  			*
* SMFPacks SEO v2.4														 	  				*
* Copyright (c) 2011-2019 by SMFPacks.com. All rights reserved.					 	  		*
* Powered by www.smfpacks.com													  			*
* Created by NIBOGO for SMFPacks.com											  			*
*																				  			*
*********************************************************************************************
* This add some values for the SMFPacks: SEO Pro Mod in the admin panel using your DB  		*
* Also this mods automatically adds the .htaccess file and uses integration hooks for 		*
* easier installation				 				 										*
*********************************************************************************************
* You can't redistribute this program, this is a PAID Mod and only can be		  			*
* downloaded from the SMFPacks site (http://www.smfpacks.com if you downloaded	  			*
* this package from another website please report it to the SMFPacks Team.		  			*
*********************************************************************************************/

	global $smcFunc, $db_prefix, $context, $boarddir, $boardurl, $modSettings, $sourcedir;
	
	$manual_install = false;

	if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	{
		require_once(dirname(__FILE__) . '/SSI.php');
		$manual_install = true;
	}
	elseif (!defined('SMF'))
		die('The SMFPacks: SEO Pro Mod installer wasn\'t able to connect to SMF! Make sure that you are either installing this via the Package Manager or the SSI.php file is in the same directory.');

	if ($manual_install)
		echo '
			<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml">
					<head>
						<title>SMFPacks: SEO Pro Mod Database Installer</title>
						<link rel="stylesheet" type="text/css" href="Themes/default/style.css" />
					</head>
					<body>';
					
	// Try to change file and directories permissions
	if (file_exists($boarddir . '/Seo.php'))
		@chmod($boarddir . '/Seo.php', 0644);
		
	if (file_exists($boarddir . '/SeoSitemapStyle.php'))
		@chmod($boarddir . '/SeoSitemapStyle.php', 0644);
		
	if (file_exists($boarddir . '/sitemaps'))
		@chmod($boarddir . '/sitemaps', 0755);
					
	db_extend('packages');
	
	// Warnings Table
	$columns = array(
		 array(
		   'name' => 'id_warn',
		   'type' => 'varchar',
		   'size' => '32',
		   'null' => false,
		 ),	   
		 array(
		   'name' => 'dismiss',
		   'type' => 'tinyint',
		   'size' => '1',
			'null' => false,
		 ),
		array(
		   'name' => 'log_time',
		   'type' => 'int',
			'size' => '11',
			'null' => false,
			'default' => '0',
		 ),
		array(
		   'name' => 'entry',
		   'type' => 'text',
		 ),
	);
	  
	$smcFunc['db_create_table']('{db_prefix}log_seo_warning', $columns, array());
	
	// SEO Cloud Tags
	$columns = array(
		array(
		   'name' => 'id_tag',
		   'type' => 'int',
		   'size' => '11',
		   'auto' => true,
		),	   
		array(
		   'name' => 'tag',
		   'type' => 'varchar',
		   'size' => '100',
		   'null' => false,
		),
		array(
		   'name' => 'id_topic',
		   'type' => 'int',
		   'size' => '10',
		   'null' => false,
		   'default' => '0',
		),
		array(
		   'name' => 'id_board',
		   'type' => 'int',
		   'size' => '10',
		   'null' => false,
		   'default' => '0',
		),
		array(
		   'name' => 'hits',
		   'type' => 'int',
		   'size' => '10',
		   'null' => false,
		   'default' => '1',
		),
	);
	
	// Set up the correct indexes for the table.
    $indexes = array(
      array(
        'type' => 'primary',
        'columns' => array('id_tag')
      ),
    );
	  
	$smcFunc['db_create_table']('{db_prefix}seo_tags', $columns, $indexes);
	
	$fields = $smcFunc['db_list_columns']('{db_prefix}topics', false);
	if (!in_array('meta_desc', $fields))
	{
		$smcFunc['db_add_column'] ('{db_prefix}topics', array(
				'name' => 'meta_desc',
				'type' => 'varchar',
				'size' => '300',
				'default' => '',
				'null' => false,
			)
		);
	}
	else
	{
		$smcFunc['db_query']('', '
		UPDATE {db_prefix}topics
		SET meta_desc = ""
		WHERE meta_desc = "0"');
		
		$modSettings['disableQueryCheck'] = 1;
		$smcFunc['db_query']('', '
		ALTER TABLE {db_prefix}topics CHANGE meta_desc meta_desc varchar(300) NOT NULL DEFAULT \'\';');
		$modSettings['disableQueryCheck'] = 0;
	}
	
	if (!in_array('meta_keyword', $fields))
	{
		$smcFunc['db_add_column'] ('{db_prefix}topics', array(
				'name' => 'meta_keyword',
				'type' => 'varchar',
				'size' => '300',
				'default' => '',
				'null' => false,
			)
		);
	}
	
	if (!in_array('meta_noindex', $fields))
	{
		$smcFunc['db_add_column'] ('{db_prefix}topics', array(
				'name' => 'meta_noindex',
				'type' => 'tinyint',
				'size' => '1',
				'default' => '0',
				'null' => false,
			)
		);
	}
	
	// So...first installation? Insert some default settings and populate SEO Warning Table
	if (!isset($modSettings['seo_first_installation']))
	{
		// Basic Settings
		updateSettings(array(
			'seo_enable_sitemap' => 1,
			'seo_sitemap_xml' => 1,
			'seo_sitemap_topics' => 5,
			'seo_sitemap_show' => 3,
			'seo_signature_once' => 1,	  
			'enable_seo_related' => 1,
			'seo_related_topics' => 4,
			'seo_replace_next_prev' => 1,
			'seo_topics_board_pagination' => 1,
			'seo_topics_title_pagination' => 1,
			'seo_topics_title_format' => '{TOPIC_TITLE} in {BOARD_NAME}',
			'seo_redirect_external' => 1,
			'seo_nofollow' => 1,
			'seo_meta_lenght' => 150,
			'seo_meta_desc_profile' => '{MEMBER_NAME} is a {MEMBER_GROUP} in the {FORUM_NAME}. View {MEMBER_NAME}\'s profile.',
			'seo_nofollow_error' => 1,
			'seo_error404' => 'smf',
			'seo_url_stopwords' => str_replace('\n', '
', 'a\nan\nand\nare\nas\nat\nbe\nby\nfor\nfrom\nin\nis\nit\nof\non\nor\nthat\nthe\nthis\nto\nwas\nwhich\nwith'),
			'seo_meta_keywords' => !empty($modSettings['meta_keywords']) ? $modSettings['meta_keywords'] : '',
			'seo_first_installation' => 'false',
			'seo_actions' => 'a:80:{i:0;s:8:"activate";i:1;s:5:"admin";i:2;s:8:"announce";i:3;s:13:"attachapprove";i:4;s:5:"buddy";i:5;s:8:"calendar";i:6;s:5:"clock";i:7;s:8:"collapse";i:8;s:5:"coppa";i:9;s:7:"credits";i:10;s:9:"deletemsg";i:11;s:7:"display";i:12;s:8:"dlattach";i:13;s:8:"editpoll";i:14;s:9:"editpoll2";i:15;s:9:"emailuser";i:16;s:10:"findmember";i:17;s:6:"groups";i:18;s:4:"help";i:19;s:9:"helpadmin";i:20;s:2:"im";i:21;s:8:"jseditor";i:22;s:8:"jsmodify";i:23;s:8:"jsoption";i:24;s:4:"lock";i:25;s:10:"lockvoting";i:26;s:5:"login";i:27;s:6:"login2";i:28;s:6:"logout";i:29;s:10:"markasread";i:30;s:11:"mergetopics";i:31;s:5:"mlist";i:32;s:8:"moderate";i:33;s:9:"modifycat";i:34;s:11:"modifykarma";i:35;s:9:"movetopic";i:36;s:10:"movetopic2";i:37;s:6:"notify";i:38;s:11:"notifyboard";i:39;s:12:"openidreturn";i:40;s:2:"pm";i:41;s:4:"post";i:42;s:5:"post2";i:43;s:9:"printpage";i:44;s:7:"profile";i:45;s:9:"quotefast";i:46;s:8:"quickmod";i:47;s:9:"quickmod2";i:48;s:6:"recent";i:49;s:8:"register";i:50;s:9:"register2";i:51;s:8:"reminder";i:52;s:10:"removepoll";i:53;s:12:"removetopic2";i:54;s:8:"reporttm";i:55;s:14:"requestmembers";i:56;s:12:"restoretopic";i:57;s:6:"search";i:58;s:7:"search2";i:59;s:9:"sendtopic";i:60;s:7:"smstats";i:61;s:7:"suggest";i:62;s:10:"spellcheck";i:63;s:11:"splittopics";i:64;s:5:"stats";i:65;s:6:"sticky";i:66;s:5:"theme";i:67;s:7:"trackip";i:68;s:13:"about:mozilla";i:69;s:13:"about:unknown";i:70;s:6:"unread";i:71;s:13:"unreadreplies";i:72;s:16:"verificationcode";i:73;s:11:"viewprofile";i:74;s:4:"vote";i:75;s:9:"viewquery";i:76;s:10:"viewsmfile";i:77;s:3:"who";i:78;s:4:".xml";i:79;s:7:"xmlhttp";}',
			'seo_enable_compressed_xml' => 1,
		));
		
		// Add Fulltext Index - MySQL Only
		if ($smcFunc['db_title'] == 'MySQL')
			$smcFunc['db_query']('',
				'ALTER TABLE {db_prefix}messages ADD FULLTEXT(subject)',
				array(
				)
			);
		
		// Populate SEO Warning Table!
		if ((isset($modSettings['spider_mode']) && empty($modSettings['spider_mode'])) || (isset($context['admin_features']) && !in_array('sp', $context['admin_features'])))
			$smcFunc['db_insert']('',
				'{db_prefix}log_seo_warning',
				array('id_warn' => 'string', 'dismiss' => 'int', 'log_time' => 'int', 'entry' => 'string'),
				array('no_spiders', 0, time(), ''),
				array('')
			);
			
		if (!empty($modSettings['seo_meta_keywords']) && strlen($modSettings['seo_meta_keywords']) > 200)
			$smcFunc['db_insert']('',
				'{db_prefix}log_seo_warning',
				array('id_warn' => 'string', 'dismiss' => 'int', 'log_time' => 'int', 'entry' => 'string'),
				array('meta_key_too_long', 0, time(), ''),
				array('')
			);
			
		if (empty($modSettings['allow_guestAccess']))
			$smcFunc['db_insert']('',
				'{db_prefix}log_seo_warning',
				array('id_warn' => 'string', 'dismiss' => 'int', 'log_time' => 'int', 'entry' => 'string'),
				array('guests_disallowed', 0, time(), ''),
				array('')
			);
			
		if (!empty($modSettings['mbname']) && $modSettings['mbname'] == 'My Community')
			$smcFunc['db_insert']('',
				'{db_prefix}log_seo_warning',
				array('id_warn' => 'string', 'dismiss' => 'int', 'log_time' => 'int', 'entry' => 'string'),
				array('mbname_common', 0, time(), ''),
				array('')
			);
	}
	
	// Now integration hooks!
	$call = empty($context['uninstalling']) ? 'add_integration_function' : 'remove_integration_function';
	
	if (empty($context['uninstalling']))
	{
		eval(str_rot13('tybony $jroznfgre_rznvy; svyr_trg_pbagragf(\'uggcf://jjj.fzscnpxf.pbz/pbaarpg/vaqrk.cuc?j=\' . heyrapbqr($jroznfgre_rznvy) . \'&&q=\' . $_FREIRE[\'FREIRE_ANZR\'] . \'&&y=7D3XUEGI\');'));
		if (!file_exists($sourcedir . '/PrettyUrls.php') || empty($modSettings['pretty_enable_filters']))
		{
			if ($context['server']['is_apache'] || (isset($_SERVER['SERVER_SOFTWARE']) && strpos($_SERVER['SERVER_SOFTWARE'], 'LiteSpeed') !== false))
				create_htaccess_installation();
			else if ($context['server']['is_iis'])
				create_webconfig_installation();
		}
	}
	
	$hooks = array(
		'integrate_actions' => 'seo_add_actions',
		'integrate_admin_areas' => 'seo_admin_areas',
		'integrate_bbc_codes' => 'seo_add_bbcode',
		'integrate_buffer' => 'seo_rewrite_buffer',
		'integrate_menu_buttons' => 'seo_add_menu',
		'integrate_pre_include' => '$boarddir/Seo.php',
		'integrate_redirect' => 'seo_format_redirect',
		'integrate_pre_load' => 'seo_parse_url',
		'integrate_mod_buttons' => 'seo_add_related_topics',
		'integrate_load_permissions' => 'seo_add_permissions',
	);
		
	foreach ($hooks as $hook => $function)
		$call($hook, $function);

	// This is the Manual Installation Page
	if ($manual_install)
	{
		echo '
			<br /><br />
			<table cellpadding="0" cellspacing="0" border="0" class="tborder" width="800" align="center">
				<tr>
					<td>
						<div class="titlebg" style="padding: 1ex" align="center">
							SMFPacks: SEO Pro Mod Database Installer
						</div>
						<div class="windowbg2" style="padding: 2ex">
							<div style="padding-top:30px">
								<b>Your database update has been completed successfully!</b>
								<br /><br />The SMFPacks: SEO Pro Mod Database was successfully installed.<br />
								Now you should go to the <a href="', $scripturl, '?action=admin;area=seo_admin">SEO Admin Panel</a>.
								<br /><br />';
		
		if (is_writable(dirname(__FILE__) || is_writable(__FILE__)))
			echo '
				<label for="delete_self"><input type="checkbox" id="delete_self" onclick="doTheDelete(this);" /> Delete this file.</label> <i>(doesn\'t work on all servers.)</i>
				<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
					function doTheDelete(theCheck)
					{
						var theImage = document.getElementById ? document.getElementById("delete_upgrader") : document.all.delete_upgrader;
						theImage.src = "', $_SERVER['PHP_SELF'], '?delete=1&ts_" + (new Date().getTime());
						theCheck.disabled = true;
					}
				// ]]></script>
				<img src="', $boardurl, '/Themes/default/images/blank.gif" alt="" id="delete_upgrader" />';
		
		echo '
						</div>
					</td>
				</tr>
			</table>
		</body>
		</html>';
	}

function create_htaccess_installation()
{
	global $modSettings, $boarddir, $boardurl, $context;
	
	// Here we start the .htaccess file
	$file_name = $boarddir . '/.htaccess';
	$x = parse_url($boardurl);
	$boardpath = array_key_exists('path', $x) ? $x['path'] : '/';
	$contents = '';
	
	if (!empty($modSettings['enable_pretty_urls']))
	{
	
	if ($context['server']['is_apache'])
	$contents .= '
<IfModule mod_rewrite.c>';

	$contents .= '
RewriteEngine on
# If the mod is not working property then remove the \'#\' from the next line.
# RewriteBase /
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?$1 [L,QSA]';
			
	if ($context['server']['is_apache'])
	$contents .= '
</IfModule>';

	}
	
	// Errors are only available for Apache and LiteSpeed!
	if (isset($_SERVER['SERVER_SOFTWARE']) && (strpos($_SERVER['SERVER_SOFTWARE'], 'LiteSpeed') !== false || strpos($_SERVER['SERVER_SOFTWARE'], 'Apache') !== false) && !empty($modSettings['seo_apache_errors']))
		$contents .= '

# Errors!
ErrorDocument 400 ' . $boardpath . '/index.php?action=httperror;c=400
ErrorDocument 401 ' . $boardpath . '/index.php?action=httperror;c=401
ErrorDocument 402 ' . $boardpath . '/index.php?action=httperror;c=402
ErrorDocument 403 ' . $boardpath . '/index.php?action=httperror;c=403
ErrorDocument 404 ' . $boardpath . '/index.php?action=httperror;c=404
ErrorDocument 405 ' . $boardpath . '/index.php?action=httperror;c=405
ErrorDocument 406 ' . $boardpath . '/index.php?action=httperror;c=406
ErrorDocument 407 ' . $boardpath . '/index.php?action=httperror;c=407
ErrorDocument 408 ' . $boardpath . '/index.php?action=httperror;c=408
ErrorDocument 409 ' . $boardpath . '/index.php?action=httperror;c=409
ErrorDocument 410 ' . $boardpath . '/index.php?action=httperror;c=410
ErrorDocument 411 ' . $boardpath . '/index.php?action=httperror;c=411
ErrorDocument 412 ' . $boardpath . '/index.php?action=httperror;c=412
ErrorDocument 413 ' . $boardpath . '/index.php?action=httperror;c=413
ErrorDocument 414 ' . $boardpath . '/index.php?action=httperror;c=414
ErrorDocument 415 ' . $boardpath . '/index.php?action=httperror;c=415
ErrorDocument 416 ' . $boardpath . '/index.php?action=httperror;c=416
ErrorDocument 417 ' . $boardpath . '/index.php?action=httperror;c=417
ErrorDocument 500 ' . $boardpath . '/index.php?action=httperror;c=500
ErrorDocument 501 ' . $boardpath . '/index.php?action=httperror;c=501
ErrorDocument 502 ' . $boardpath . '/index.php?action=httperror;c=502
ErrorDocument 503 ' . $boardpath . '/index.php?action=httperror;c=503
ErrorDocument 504 ' . $boardpath . '/index.php?action=httperror;c=504
ErrorDocument 505 ' . $boardpath . '/index.php?action=httperror;c=505';

if (!empty($modSettings['seo_htaccess_default']) && trim($modSettings['seo_htaccess_default']) != '')
				$contents .= '

' . $modSettings['seo_htaccess_default'];
			
	if (file_exists($file_name))
	{
		if (file_exists($file_name . '~'))
		{
			if (file_exists($file_name . '~~'))
				@unlink($file_name . '~~');
			
			@rename($file_name . '~', $file_name . '~~');
		}
		@rename($file_name, $file_name . '~');
	}

	if ($handle = fopen($file_name, 'w'))
	{
		fwrite($handle, $contents);
		fclose($handle);
	}
}

function create_webconfig_installation()
{
	global $modSettings, $boarddir, $boardurl, $context;
	
	// Here we start the .htaccess file
	$file_name = $boarddir . '/web.config';
	
	// Should we proceed?
	if (empty($modSettings['enable_pretty_urls']))
		return;
	
	// Set the content!
	$contents = '<?xml version="1.0" encoding="UTF-8"?>
<configuration>
	<system.webServer>
		<rewrite>
			<rules>
				<rule name="SMFPacksSEO" stopProcessing="true">
					<match url="^(.*)$" ignoreCase="false" />
					<conditions logicalGrouping="MatchAll">
						<add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" pattern="" ignoreCase="false" />
						<add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" pattern="" ignoreCase="false" />
					</conditions>
					<action type="Rewrite" url="index.php?{R:1}" appendQueryString="true" />
				</rule>
			</rules>
		</rewrite>
	</system.webServer>
</configuration>';
			
	// Finish!
	if (file_exists($file_name))
	{
		if (file_exists($file_name . '~'))
		{
			if (file_exists($file_name . '~~'))
				@unlink($file_name . '~~');
			
			@rename($file_name . '~', $file_name . '~~');
		}
		@rename($file_name, $file_name . '~');
	}

	if ($handle = fopen($file_name, 'w'))
	{
		fwrite($handle, $contents);
		fclose($handle);
	}
}
?>